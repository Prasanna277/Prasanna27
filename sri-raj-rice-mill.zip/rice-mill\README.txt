RICE MILL FACILITY PHOTOS DIRECTORY
====================================

This directory should contain photos of your rice mill facility.

Required Images:
- mill-1.jpg - Main Processing Facility
- mill-2.jpg - Modern Milling Equipment  
- mill-3.jpg - Quality Storage Units
- mill-4.jpg - Packaging Department
- mill-5.jpg - Quality Control Lab
- mill-6.jpg - Loading Bay

Image Recommendations:
- Format: JPG, PNG, or WebP
- Size: 1200x800px or larger (landscape orientation)
- File size: Optimize for web (under 500KB each recommended)

You can add more photos by updating the riceMillPhotos array in scripts/main.js
