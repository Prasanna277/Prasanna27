// Rice Mill Facility Photos Data
const riceMillPhotos = [
    {
        image: 'images/rice-mill/mill-1.jpg',
        caption: 'Main Processing Facility'
    },
    {
        image: 'images/rice-mill/mill-2.jpg',
        caption: 'Modern Milling Equipment'
    },
    {
        image: 'images/rice-mill/mill-3.jpg',
        caption: 'Quality Storage Units'
    },
    {
        image: 'images/rice-mill/mill-4.jpg',
        caption: 'Packaging Department'
    },
    {
        image: 'images/rice-mill/mill-5.jpg',
        caption: 'Quality Control Lab'
    },
    {
        image: 'images/rice-mill/mill-6.jpg',
        caption: 'Loading Bay'
    }
];

// Rice Varieties Data
const riceVarieties = [
    {
        name: 'Basmati Rice',
        image: 'images/rice-varieties/basmati.jpg',
        description: 'Premium long-grain aromatic rice, perfect for biryanis and pulao. Known for its distinctive fragrance and fluffy texture.',
        price: '$12.99/kg'
    },
    {
        name: 'Jasmine Rice',
        image: 'images/rice-varieties/jasmine.jpg',
        description: 'Fragrant long-grain rice with a subtle floral aroma. Ideal for Asian cuisine and pairs well with curries.',
        price: '$10.99/kg'
    },
    {
        name: 'Brown Rice',
        image: 'images/rice-varieties/brown.jpg',
        description: 'Whole grain rice with the bran layer intact. Rich in fiber and nutrients, perfect for health-conscious consumers.',
        price: '$9.99/kg'
    },
    {
        name: 'White Rice',
        image: 'images/rice-varieties/white.jpg',
        description: 'Classic polished white rice, versatile and easy to cook. A staple for everyday meals.',
        price: '$7.99/kg'
    },
    {
        name: 'Red Rice',
        image: 'images/rice-varieties/red.jpg',
        description: 'Nutritious red-hulled rice with a nutty flavor. High in antioxidants and fiber.',
        price: '$11.99/kg'
    },
    {
        name: 'Black Rice',
        image: 'images/rice-varieties/black.jpg',
        description: 'Premium black rice, also known as forbidden rice. Rich in antioxidants and has a unique nutty flavor.',
        price: '$15.99/kg'
    },
    {
        name: 'Sona Masoori',
        image: 'images/rice-varieties/sona-masoori.jpg',
        description: 'Popular medium-grain rice from South India. Light and fluffy, perfect for daily cooking.',
        price: '$8.99/kg'
    },
    {
        name: 'Arborio Rice',
        image: 'images/rice-varieties/arborio.jpg',
        description: 'Italian short-grain rice perfect for risotto. Creamy texture when cooked properly.',
        price: '$13.99/kg'
    }
];

// Initialize the page
document.addEventListener('DOMContentLoaded', function() {
    renderFacilityGallery();
    renderRiceVarieties();
    initHeroSlider();
    initSmoothScroll();
});

// Render Facility Gallery
function renderFacilityGallery() {
    const galleryContainer = document.getElementById('facilityGallery');
    if (!galleryContainer) return;

    galleryContainer.innerHTML = riceMillPhotos.map(photo => `
        <div class="gallery-item">
            <img src="${photo.image}" alt="${photo.caption}" loading="lazy">
            <div class="gallery-caption">${photo.caption}</div>
        </div>
    `).join('');
}

// Render Rice Varieties
function renderRiceVarieties() {
    const riceContainer = document.getElementById('riceVarieties');
    if (!riceContainer) return;

    riceContainer.innerHTML = riceVarieties.map(rice => `
        <div class="rice-card">
            <img src="${rice.image}" alt="${rice.name}" class="rice-card-image" loading="lazy">
            <div class="rice-card-content">
                <h3 class="rice-card-title">${rice.name}</h3>
                <p class="rice-card-description">${rice.description}</p>
                <div class="rice-card-price">${rice.price}</div>
            </div>
        </div>
    `).join('');
}

// Hero Slider Functionality
function initHeroSlider() {
    const slides = document.querySelectorAll('.hero-slide');
    const indicators = document.querySelectorAll('.indicator');
    const prevBtn = document.querySelector('.hero-btn.prev');
    const nextBtn = document.querySelector('.hero-btn.next');
    
    if (slides.length === 0) return;

    let currentSlide = 0;
    const totalSlides = slides.length;

    function showSlide(index) {
        // Remove active class from all slides and indicators
        slides.forEach(slide => slide.classList.remove('active'));
        indicators.forEach(indicator => indicator.classList.remove('active'));

        // Add active class to current slide and indicator
        slides[index].classList.add('active');
        if (indicators[index]) {
            indicators[index].classList.add('active');
        }
    }

    function nextSlide() {
        currentSlide = (currentSlide + 1) % totalSlides;
        showSlide(currentSlide);
    }

    function prevSlide() {
        currentSlide = (currentSlide - 1 + totalSlides) % totalSlides;
        showSlide(currentSlide);
    }

    // Event listeners for buttons
    if (nextBtn) {
        nextBtn.addEventListener('click', nextSlide);
    }
    if (prevBtn) {
        prevBtn.addEventListener('click', prevSlide);
    }

    // Event listeners for indicators
    indicators.forEach((indicator, index) => {
        indicator.addEventListener('click', () => {
            currentSlide = index;
            showSlide(currentSlide);
        });
    });

    // Auto-advance slides every 5 seconds
    setInterval(nextSlide, 5000);
}

// Smooth Scroll for Navigation Links
function initSmoothScroll() {
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            
            // Only handle anchor links
            if (href.startsWith('#')) {
                e.preventDefault();
                const targetId = href.substring(1);
                const targetElement = document.getElementById(targetId);
                
                if (targetElement) {
                    targetElement.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            }
        });
    });
}
