RICE VARIETY PHOTOS DIRECTORY
==============================

This directory should contain photos of your rice varieties.

Current Rice Varieties (update in scripts/main.js):
- basmati.jpg - Basmati Rice
- jasmine.jpg - Jasmine Rice
- brown.jpg - Brown Rice
- white.jpg - White Rice
- red.jpg - Red Rice
- black.jpg - Black Rice
- sona-masoori.jpg - Sona Masoori
- arborio.jpg - Arborio Rice

Image Recommendations:
- Format: JPG, PNG, or WebP
- Size: 800x800px (square) for best display
- File size: Optimize for web (under 300KB each recommended)

To add or modify rice varieties, edit the riceVarieties array in scripts/main.js
